// Cooldown sweep over an icon (Godot 4, canvas_item). MIT-0 licence: use freely, no attribution needed.
// Set `progress` from 0 (just used) to 1 (ready). The dark wedge shrinks clockwise from 12 o'clock.
shader_type canvas_item;

uniform float progress : hint_range(0.0, 1.0) = 0.35;
uniform vec4 shade : source_color = vec4(0.0, 0.0, 0.0, 0.6);

void fragment() {
    vec4 c = texture(TEXTURE, UV);
    vec2 p = UV - vec2(0.5);
    float a = atan(p.x, -p.y) / 6.2831853 + 0.5;   // 0 at 12 o'clock, clockwise
    float dark = step(progress, a) * (1.0 - step(1.0, progress));
    c.rgb = mix(c.rgb, shade.rgb, dark * shade.a);
    COLOR = c;
}
