// Rarity shimmer for an icon tile (Godot 4, canvas_item). MIT-0 licence: use freely, no attribution needed.
// Put it on a TextureRect / Sprite2D that shows a legendary or mythic tile. A soft light band sweeps across.
shader_type canvas_item;

uniform vec4 shimmer_colour : source_color = vec4(1.0, 0.96, 0.84, 1.0);
uniform float speed = 0.35;        // sweeps per second
uniform float width = 0.08;        // band width (0..1 of the tile)
uniform float strength = 0.55;     // 0 = off
uniform float pause = 1.2;         // seconds between sweeps

void fragment() {
    vec4 c = texture(TEXTURE, UV);
    float cycle = 1.0 / speed + pause;
    float t = mod(TIME, cycle) * speed;           // 0..1 during the sweep, > 1 while paused
    float d = (UV.x + UV.y) * 0.5 - (t * 1.6 - 0.3);
    float band = exp(-d * d / (width * width * 0.5));
    c.rgb = mix(c.rgb, shimmer_colour.rgb, band * strength * c.a);
    COLOR = c;
}
