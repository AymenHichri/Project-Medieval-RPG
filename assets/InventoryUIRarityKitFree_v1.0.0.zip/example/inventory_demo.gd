# Inventory demo (Godot 4). MIT-0 licence: use freely, no attribution needed.
# Open inventory_demo.tscn in any Godot 4 project that contains this kit's folder, then run the scene (F6).
# Drag items between slots; hover an item for its rarity tooltip.
extends Control

const SLOT := preload("slot.gd")

var base := ""


func _ready() -> void:
	base = get_script().resource_path.get_base_dir().get_base_dir()   # kit root (one level above example/)
	var bg := ColorRect.new()
	bg.color = Color(0.07, 0.075, 0.09)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var panel := NinePatchRect.new()
	panel.texture = load(base + "/ui/panels/panel_inventory.png")
	var s: Array = JSON.parse_string(FileAccess.get_file_as_string(base + "/ui/panels/slices.json"))["panel_inventory"]
	panel.patch_margin_left = s[0]; panel.patch_margin_top = s[1]; panel.patch_margin_right = s[2]; panel.patch_margin_bottom = s[3]
	panel.position = Vector2(40, 40)
	panel.size = Vector2(520, 330)
	add_child(panel)
	var grid := GridContainer.new()
	grid.columns = 6
	grid.position = Vector2(64, 64)
	grid.add_theme_constant_override("h_separation", 0)
	grid.add_theme_constant_override("v_separation", 0)
	add_child(grid)
	var items: Array = JSON.parse_string(FileAccess.get_file_as_string(base + "/example/demo_items.json"))
	for i in 18:
		var slot := TextureRect.new()
		slot.set_script(SLOT)
		slot.frame_empty = load(base + "/ui/slots/slot_empty_128.png")
		slot.frame_hover = load(base + "/ui/slots/slot_hover_128.png")
		if i < items.size():
			var it: Dictionary = items[i]
			slot.item = {"name": it["name"], "tier": int(it["tier"]), "count": int(it["count"]),
				"icon": load(base + "/" + it["icon"])}
		grid.add_child(slot)
	print("inventory demo ready: ", grid.get_child_count(), " slots, ", items.size(), " items")
