# Inventory slot for the demo (Godot 4). MIT-0 licence: use freely, no attribution needed.
# Shows a frame, an item icon on its rarity tile, a stack count, drag and drop between slots, and a rarity tooltip.
extends TextureRect

const TIER_NAMES := ["Poor", "Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic"]
const TIER_COLOURS := [Color("#8a8a8a"), Color("#d8d8d8"), Color("#3fbf3f"), Color("#3b7fe0"), Color("#a346e0"), Color("#ff9a1f"), Color("#e03a3a")]

var item: Dictionary = {}      # {"name": String, "icon": Texture2D, "tier": int, "count": int}
var frame_empty: Texture2D
var frame_hover: Texture2D
@onready var icon_rect := TextureRect.new()
@onready var count_label := Label.new()


func _ready() -> void:
	custom_minimum_size = Vector2(80, 80)
	expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	texture = frame_empty
	icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	icon_rect.offset_left = 6; icon_rect.offset_top = 6; icon_rect.offset_right = -6; icon_rect.offset_bottom = -6
	icon_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(icon_rect)
	count_label.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	count_label.offset_left = -34; count_label.offset_top = -26; count_label.offset_right = -8; count_label.offset_bottom = -4
	count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	count_label.add_theme_color_override("font_outline_color", Color.BLACK)
	count_label.add_theme_constant_override("outline_size", 4)
	add_child(count_label)
	mouse_entered.connect(func(): texture = frame_hover)
	mouse_exited.connect(func(): texture = frame_empty)
	refresh()


func refresh() -> void:
	icon_rect.texture = item.get("icon")
	var n: int = item.get("count", 0)
	count_label.text = str(n) if n > 1 else ""
	tooltip_text = item.get("name", "")


func _make_custom_tooltip(_for_text: String) -> Object:
	if item.is_empty():
		return null
	var box := PanelContainer.new()
	var v := VBoxContainer.new()
	box.add_child(v)
	var title := Label.new()
	title.text = item["name"]
	title.add_theme_color_override("font_color", TIER_COLOURS[item["tier"]])
	v.add_child(title)
	var tier := Label.new()
	tier.text = TIER_NAMES[item["tier"]]
	tier.add_theme_color_override("font_color", TIER_COLOURS[item["tier"]].darkened(0.2))
	v.add_child(tier)
	return box


func _get_drag_data(_at: Vector2) -> Variant:
	if item.is_empty():
		return null
	var preview := TextureRect.new()
	preview.texture = item["icon"]
	preview.custom_minimum_size = Vector2(64, 64)
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	set_drag_preview(preview)
	return self


func _can_drop_data(_at: Vector2, data: Variant) -> bool:
	return data is TextureRect and data != self and data.has_method("refresh")


func _drop_data(_at: Vector2, data: Variant) -> void:
	var other: Dictionary = data.item
	data.item = item
	item = other
	data.refresh()
	refresh()
